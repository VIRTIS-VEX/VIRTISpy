#!/usr/bin/env python
from distutils.core import setup
setup(name='VIRTISpy',
      version='0.1.0',
      description='Python data reader for VIRTIS-VEx cubes',
      license='GPL',
      author='Romolo Politi',
      author_email='romolo.politi@iasf-roma.inaf.it',
      url='http://code.google.com/p/virtispy',
      py_modules=['VIRTISpy'],
)